const merge = require("webpack-merge");

const proConfig = {
  devtool: "cheap-module-source-map",
  mode: "production"
};

module.exports = proConfig;
