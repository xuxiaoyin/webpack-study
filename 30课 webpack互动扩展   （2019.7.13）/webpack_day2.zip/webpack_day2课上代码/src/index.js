import _ from "lodash";
console.log(_.join(["a", "b", "c", "****"]));
