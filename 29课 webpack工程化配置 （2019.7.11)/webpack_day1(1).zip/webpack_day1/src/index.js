import a from "./a.js";
import b from "./b.js";
import pic from "./img/timg.jpeg";
import logo from "./img/LOGO108.png";

import "./css/index.css";
import "./css/test.scss";

console.log(pic);
console.log(logo);

a();
b();

console.log("hello webpack");
