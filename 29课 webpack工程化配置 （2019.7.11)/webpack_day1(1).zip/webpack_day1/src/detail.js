console.log(" detail js");
