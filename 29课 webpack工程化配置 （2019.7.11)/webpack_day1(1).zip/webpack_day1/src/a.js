function a() {
  console.log("i am a");
}

module.exports = a;
