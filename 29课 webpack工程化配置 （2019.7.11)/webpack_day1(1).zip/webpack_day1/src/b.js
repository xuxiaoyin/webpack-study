function b() {
  console.log("i am b");
}
module.exports = b;
