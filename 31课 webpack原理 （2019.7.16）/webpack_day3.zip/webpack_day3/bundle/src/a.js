import b from "./b.js";

const a = "world" + b;

export default a;
