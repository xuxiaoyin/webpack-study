import a from "./a.js";
console.log("hello" + a);

//hello world!!!
