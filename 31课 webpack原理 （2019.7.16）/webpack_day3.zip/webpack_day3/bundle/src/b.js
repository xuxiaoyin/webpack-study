const b = "!!!";

export default b;
